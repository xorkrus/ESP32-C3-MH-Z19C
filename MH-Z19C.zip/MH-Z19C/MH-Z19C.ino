// main.ino
#include "config.h"
#include "globals.h"
#include "display.h"
#include "sensors.h"
#include "network.h"
#include "web.h"
#include "button.h"

// ========== ОПРЕДЕЛЕНИЯ ГЛОБАЛЬНЫХ ПЕРЕМЕННЫХ (extern из globals.h) ==========
TwoWire I2Cbus = TwoWire(0);
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &I2Cbus, OLED_RESET);

WiFiUDP ntpUDP;
NTPClient timeClient(ntpUDP, "pool.ntp.org", 3 * 3600, 60000);

WiFiClient espClient;
PubSubClient mqttClient(espClient);

WebServer server(80);

unsigned long lastUpdate = 0;
const unsigned long UPDATE_INTERVAL = 100;
unsigned long lastMqttSend = 0;
const unsigned long MQTT_INTERVAL = 60000;
unsigned long lastTempRead = 0;
const unsigned long TEMP_READ_INTERVAL = 5000;

int currentPpm = -1;
float currentTemp = -127.0;
bool displayState = true;
bool scheduleEnabled = true;
unsigned long buttonWakeUntil = 0;

Bubble bubbles[MAX_BUBBLES];
int numberOffsetX = 0;
int numberOffsetY = 0;

int levelNamePos = 0;
unsigned long lastLevelPosChange = 0;
const unsigned long LEVEL_POS_INTERVAL = 10000;

int co2History[HISTORY_SIZE];
float tempHistory[HISTORY_SIZE];
int historyIndex = 0;
int historyCount = 0;
unsigned long lastHistoryAdd = 0;
const unsigned long HISTORY_ADD_INTERVAL = 60000;

String lastIP = "";
unsigned long ipDisplayUntil = 0;

bool apMode = false;
const String apSSIDprefix = "CO2Monitor_";

Config config;

// ========== ОПРЕДЕЛЕНИЯ ДЛЯ КНОПКИ ==========
ButtonState btnState = BUTTON_IDLE;
unsigned long buttonPressTime = 0;
bool buttonLongPressHandled = false;
const unsigned long LONG_PRESS_MS = 1000;

// ========== УКАЗАТЕЛИ ДЛЯ ДАТЧИКА ТЕМПЕРАТУРЫ ==========
OneWire* oneWire = nullptr;
DallasTemperature* sensors = nullptr;

// ========== SETUP ==========
void setup() {
  Serial.begin(115200);
  delay(1000);
  Serial.println("CO2 Monitor v" + String(FW_VERSION));

  I2Cbus.begin(I2C_SDA, I2C_SCL);
  I2Cbus.setClock(100000);
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println("SSD1306 not found");
    while (1);
  }
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(0,0);
  display.println("CO2 Monitor v" + String(FW_VERSION));
  display.println("Loading...");
  display.display();

  loadConfig();

  if (config.temp_enabled) {
    oneWire = new OneWire(config.temp_gpio);
    sensors = new DallasTemperature(oneWire);
    sensors->begin();
  }

  pinMode(PWM_PIN, INPUT);
  if (config.button_enabled) {
    pinMode(config.button_gpio, INPUT_PULLUP);
  }

  setupWiFi();

  if (!apMode) {
    mqttClient.setServer(config.mqtt_server, config.mqtt_port);
  }

  if (!apMode) {
    timeClient.begin();
    timeClient.setTimeOffset(config.timezone * 3600);
    timeClient.update();
  }

  initBubbles();
  randomSeed(analogRead(0));

  for (int i = 0; i < HISTORY_SIZE; i++) {
    co2History[i] = 0;
    tempHistory[i] = -127.0;
  }

  setupWebServer();

  setDisplayPower(true);
  updateDisplayContent();

  Serial.println("Setup complete");
}

// ========== LOOP ==========
void loop() {
  unsigned long now = millis();

  if (!apMode && WiFi.status() != WL_CONNECTED) {
    setupWiFi();
  }

  if (!apMode) {
    if (!mqttClient.connected()) {
      reconnectMQTT();
    }
    mqttClient.loop();

    static unsigned long lastTimeUpdate = 0;
    if (now - lastTimeUpdate >= 5000) {
      lastTimeUpdate = now;
      timeClient.update();
    }
  }

  int ppm = readCO2FromPWM(PWM_PIN);
  if (ppm > 0) {
    currentPpm = ppm;
    Serial.print("CO2: ");
    Serial.print(currentPpm);
    Serial.println(" ppm");
  } else {
    Serial.println("PWM read error");
    currentPpm = -1;
  }

  if (now - lastTempRead >= TEMP_READ_INTERVAL) {
    lastTempRead = now;
    readTemperature();
    if (currentTemp > -100.0) {
      Serial.print("Temp: ");
      Serial.println(currentTemp);
    }
  }

  if (now - lastHistoryAdd >= HISTORY_ADD_INTERVAL) {
    lastHistoryAdd = now;
    addToHistory(currentPpm, currentTemp);
  }

  if (!config.disable_movement && (now - lastLevelPosChange >= LEVEL_POS_INTERVAL)) {
    lastLevelPosChange = now;
    levelNamePos = (levelNamePos + 1) % 2;
  }

  handleButton();

  bool needOn = shouldDisplayOn();
  setDisplayPower(needOn);

  if (now - lastUpdate >= UPDATE_INTERVAL) {
    lastUpdate = now;
    if (displayState) {
      if (!config.disable_movement) {
        numberOffsetX = random(-3, 4);
        numberOffsetY = random(-3, 4);
      } else {
        numberOffsetX = 0;
        numberOffsetY = 0;
      }
      updateDisplayContent();
    }
  }

  if (!apMode && (now - lastMqttSend >= MQTT_INTERVAL)) {
    lastMqttSend = now;
    if (currentPpm > 0 || (config.temp_enabled && currentTemp > -100.0 && currentTemp < 100.0)) {
      sendMqtt();
    }
  }

  server.handleClient();
  delay(10);
}
