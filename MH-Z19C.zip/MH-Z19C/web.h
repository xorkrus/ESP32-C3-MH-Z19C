#ifndef WEB_H
#define WEB_H

#include <Arduino.h>

void handleRoot();
void handleApiData();
void handleConfig();
void handleSave();
void setupWebServer();
void addToHistory(int co2, float temp);

#endif