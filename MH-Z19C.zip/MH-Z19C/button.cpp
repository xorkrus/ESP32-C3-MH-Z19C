#include "button.h"
#include "globals.h"
#include "config.h"
#include "display.h"

void handleButton() {
  if (!config.button_enabled) return;

  bool pinState = digitalRead(config.button_gpio);
  unsigned long now = millis();

  switch (btnState) {
    case BUTTON_IDLE:
      if (pinState == LOW) {
        btnState = BUTTON_PRESSED;
        buttonPressTime = now;
        buttonLongPressHandled = false;
      }
      break;

    case BUTTON_PRESSED:
      if (pinState == HIGH) {
        if (!buttonLongPressHandled && (now - buttonPressTime) < LONG_PRESS_MS) {
          buttonWakeUntil = now + config.button_wake_time * 1000UL;
          scheduleEnabled = false;
        }
        btnState = BUTTON_IDLE;
      } else if ((now - buttonPressTime) >= LONG_PRESS_MS && !buttonLongPressHandled) {
        buttonLongPressHandled = true;
        buttonWakeUntil = now + 0xFFFFFFFF;
        scheduleEnabled = false;
        setDisplayPower(true);
      }
      break;
  }

  if (buttonLongPressHandled && digitalRead(config.button_gpio) == HIGH) {
    buttonWakeUntil = 0;
    scheduleEnabled = true;
    setDisplayPower(shouldDisplayOn());
    btnState = BUTTON_IDLE;
  }
}