#include "network.h"
#include "globals.h"
#include "config.h"

void setupAP() {
  String apSSID = apSSIDprefix + WiFi.macAddress().substring(9);
  Serial.println("Starting Access Point: " + apSSID);
  bool result = WiFi.softAP(apSSID.c_str(), "12345678");
  if (result) {
    Serial.println("AP Started. IP: " + WiFi.softAPIP().toString());
    lastIP = WiFi.softAPIP().toString();
    apMode = true;
    ipDisplayUntil = millis() + 5000;
  } else {
    Serial.println("AP Failed!");
  }
}

void setupWiFi() {
  if (apMode) return;

  if (WiFi.status() == WL_CONNECTED) return;
  Serial.print("Connecting to WiFi");
  WiFi.disconnect(true);
  WiFi.mode(WIFI_STA);
  WiFi.begin(config.ssid, config.password);
  int attempts = 0;
  while (WiFi.status() != WL_CONNECTED && attempts < 30) {
    delay(500);
    Serial.print(".");
    attempts++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println(" OK!");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
    lastIP = WiFi.localIP().toString();
    ipDisplayUntil = millis() + 5000;
    apMode = false;
  } else {
    Serial.println(" Failed! Switching to AP mode.");
    setupAP();
  }
}

void reconnectMQTT() {
  if (apMode) return;
  while (!mqttClient.connected()) {
    Serial.print("Connecting to MQTT...");
    String clientId = "ESP32C3-" + String(random(0xffff), HEX);
    if (strlen(config.mqtt_user) == 0) {
      if (mqttClient.connect(clientId.c_str())) {
        Serial.println("connected");
      } else {
        Serial.print("failed, rc=");
        Serial.print(mqttClient.state());
        delay(5000);
      }
    } else {
      if (mqttClient.connect(clientId.c_str(), config.mqtt_user, config.mqtt_pass)) {
        Serial.println("connected");
      } else {
        Serial.print("failed, rc=");
        Serial.print(mqttClient.state());
        delay(5000);
      }
    }
  }
}

void sendMqtt() {
  if (apMode) return;
  if (currentPpm > 0) {
    String payload = String(currentPpm);
    if (mqttClient.publish(config.mqtt_topic_co2, payload.c_str())) {
      Serial.print("MQTT CO2 sent: ");
      Serial.println(payload);
    } else {
      Serial.println("MQTT CO2 publish failed");
    }
  }
  if (config.temp_enabled && currentTemp > -100.0 && currentTemp < 100.0) {
    String payload = String(currentTemp, 1);
    if (mqttClient.publish(config.mqtt_topic_temp, payload.c_str())) {
      Serial.print("MQTT Temp sent: ");
      Serial.println(payload);
    } else {
      Serial.println("MQTT Temp publish failed");
    }
  }
}