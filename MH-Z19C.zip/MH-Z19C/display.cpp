#include "display.h"
#include "config.h"
#include "globals.h"

bool isScheduleOff() {
  if (!scheduleEnabled) return false;

  timeClient.update();
  int hour = timeClient.getHours();
  int minute = timeClient.getMinutes();
  int day = timeClient.getDay();
  int dayMask = (day == 0) ? (1 << 6) : (1 << (day - 1));

  for (int i = 0; i < 3; i++) {
    if (strlen(config.schedule[i]) == 0) continue;
    char *token = strtok(config.schedule[i], ",");
    if (!token) continue;
    char *daysStr = strtok(NULL, ",");
    int mask = daysStr ? atoi(daysStr) : 127;
    if ((mask & dayMask) == 0) continue;

    int startHour, startMin, endHour, endMin;
    if (sscanf(token, "%d:%d-%d:%d", &startHour, &startMin, &endHour, &endMin) == 4) {
      int start = startHour * 60 + startMin;
      int end = endHour * 60 + endMin;
      int now = hour * 60 + minute;
      if (start <= end) {
        if (now >= start && now < end) return true;
      } else {
        if (now >= start || now < end) return true;
      }
    }
  }
  return false;
}

bool shouldDisplayOn() {
  if (buttonWakeUntil > millis()) {
    return true;
  } else {
    scheduleEnabled = true;
  }
  return !isScheduleOff();
}

void setDisplayPower(bool on) {
  if (on && !displayState) {
    display.ssd1306_command(SSD1306_DISPLAYON);
    displayState = true;
    updateDisplayContent();
  } else if (!on && displayState) {
    display.ssd1306_command(SSD1306_DISPLAYOFF);
    displayState = false;
  }
}

void initBubbles() {
  for (int i = 0; i < MAX_BUBBLES; i++) {
    bubbles[i].active = random(0, 100) < 80;
    if (bubbles[i].active) {
      bubbles[i].x = random(0, SCREEN_WIDTH);
      bubbles[i].y = random(0, SCREEN_HEIGHT);
      bubbles[i].radius = random(2, 6);
      bubbles[i].speed = random(1, 3);
      bubbles[i].filled = random(0, 2);
    }
  }
}

void updateBubbles() {
  if (config.disable_animation) return;
  for (int i = 0; i < MAX_BUBBLES; i++) {
    if (bubbles[i].active) {
      bubbles[i].y -= bubbles[i].speed;
      if (bubbles[i].y + bubbles[i].radius < 0) {
        bubbles[i].y = SCREEN_HEIGHT + bubbles[i].radius;
        bubbles[i].x = random(0, SCREEN_WIDTH);
        bubbles[i].radius = random(2, 6);
        bubbles[i].speed = random(1, 3);
        bubbles[i].filled = random(0, 2);
      }
    } else {
      if (random(0, 100) < 2) {
        bubbles[i].active = true;
        bubbles[i].x = random(0, SCREEN_WIDTH);
        bubbles[i].y = SCREEN_HEIGHT + random(0, 10);
        bubbles[i].radius = random(2, 6);
        bubbles[i].speed = random(1, 3);
        bubbles[i].filled = random(0, 2);
      }
    }
  }
}

void drawBubbles(int digitsX, int digitsY, int digitsW, int digitsH) {
  if (config.disable_animation) return;
  for (int i = 0; i < MAX_BUBBLES; i++) {
    if (bubbles[i].active) {
      bool intersects = (bubbles[i].x + bubbles[i].radius > digitsX && bubbles[i].x - bubbles[i].radius < digitsX + digitsW &&
                         bubbles[i].y + bubbles[i].radius > digitsY && bubbles[i].y - bubbles[i].radius < digitsY + digitsH);
      if (!intersects) {
        if (bubbles[i].filled) {
          display.fillCircle(bubbles[i].x, bubbles[i].y, bubbles[i].radius, SSD1306_WHITE);
        } else {
          display.drawCircle(bubbles[i].x, bubbles[i].y, bubbles[i].radius, SSD1306_WHITE);
        }
      }
    }
  }
}

void updateDisplayContent() {
  if (!displayState) return;

  display.clearDisplay();

  if (ipDisplayUntil > millis()) {
    display.setFont(NULL);
    display.setTextSize(1);
    display.setCursor(0, 0);
    display.println("IP:");
    display.println(lastIP);
    if (apMode) {
      display.println("AP mode");
      display.println("Connect to:");
      display.println(apSSIDprefix + WiFi.macAddress().substring(9));
    } else {
      display.println("Connect to");
      display.println("/config");
    }
    display.display();
    return;
  }

  int levelIndex = 0;
  for (int i = 0; i < 4; i++) {
    if (currentPpm < config.thresholds[i]) {
      levelIndex = i;
      break;
    }
    if (i == 3 && currentPpm >= config.thresholds[3]) levelIndex = 3;
  }

  if (config.disable_movement) {
    numberOffsetX = 0;
    numberOffsetY = 0;
    levelNamePos = 0;
  }

  display.setFont(NULL);
  display.setTextSize(config.font_scale_co2);
  char ppmStr[6];
  sprintf(ppmStr, "%d", currentPpm);
  int16_t x1, y1;
  uint16_t w, h;
  display.getTextBounds(ppmStr, 0, 0, &x1, &y1, &w, &h);
  int textWidth = w;
  int textHeight = h;
  int x = (SCREEN_WIDTH / 2) - (textWidth / 2) + numberOffsetX;
  int y = (SCREEN_HEIGHT / 2) - (textHeight / 2) + numberOffsetY;
  if (x < 0) x = 0;
  if (x + textWidth > SCREEN_WIDTH) x = SCREEN_WIDTH - textWidth;
  if (y < 0) y = 0;
  if (y + textHeight > SCREEN_HEIGHT) y = SCREEN_HEIGHT - textHeight;

  updateBubbles();
  drawBubbles(x, y, textWidth, textHeight);

  display.setTextColor(SSD1306_WHITE);
  if (currentPpm < 0) {
    display.setTextSize(1);
    display.setCursor(20, 20);
    display.println(F("ERR"));
  } else {
    display.setCursor(x, y);
    display.print(ppmStr);
  }

  display.setTextSize(config.font_scale_info);
  int levelX, levelY = SCREEN_HEIGHT - 8 * config.font_scale_info;
  if (config.disable_movement || levelNamePos == 0) {
    levelX = 3;
  } else {
    int levelWidth = strlen(config.level_names[levelIndex]) * 6 * config.font_scale_info;
    levelX = SCREEN_WIDTH - levelWidth - 3;
  }
  display.setCursor(levelX, levelY);
  display.print(config.level_names[levelIndex]);

  if (config.temp_enabled && currentTemp > -100.0 && currentTemp < 100.0) {
    display.setTextSize(config.font_scale_temp);
    char tempStr[10];
    dtostrf(currentTemp, 4, 1, tempStr);
    strcat(tempStr, " C");
    int tempWidth = strlen(tempStr) * 6 * config.font_scale_temp;
    display.setCursor(SCREEN_WIDTH - tempWidth - 2, 2);
    display.print(tempStr);
  }

  if (!config.disable_movement) {
    display.drawRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, SSD1306_WHITE);
    if (levelIndex >= 2) {
      display.drawRect(1, 1, SCREEN_WIDTH-2, SCREEN_HEIGHT-2, SSD1306_WHITE);
    }
  }

  display.display();
}