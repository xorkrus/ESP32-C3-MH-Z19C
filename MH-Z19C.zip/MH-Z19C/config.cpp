#include "config.h"
#include <SPIFFS.h>
#include <ArduinoJson.h>

void loadConfig() {
  if (!SPIFFS.begin(true)) {
    Serial.println("SPIFFS mount failed");
    return;
  }
  if (SPIFFS.exists("/config.json")) {
    File file = SPIFFS.open("/config.json", "r");
    if (file) {
      JsonDocument doc;
      DeserializationError error = deserializeJson(doc, file);
      if (!error) {
        strlcpy(config.ssid, doc["ssid"] | config.ssid, sizeof(config.ssid));
        strlcpy(config.password, doc["password"] | config.password, sizeof(config.password));
        strlcpy(config.mqtt_server, doc["mqtt_server"] | config.mqtt_server, sizeof(config.mqtt_server));
        config.mqtt_port = doc["mqtt_port"] | config.mqtt_port;
        strlcpy(config.mqtt_user, doc["mqtt_user"] | config.mqtt_user, sizeof(config.mqtt_user));
        strlcpy(config.mqtt_pass, doc["mqtt_pass"] | config.mqtt_pass, sizeof(config.mqtt_pass));
        strlcpy(config.mqtt_topic_co2, doc["mqtt_topic_co2"] | config.mqtt_topic_co2, sizeof(config.mqtt_topic_co2));
        strlcpy(config.mqtt_topic_temp, doc["mqtt_topic_temp"] | config.mqtt_topic_temp, sizeof(config.mqtt_topic_temp));
        strlcpy(config.ntp_server, doc["ntp_server"] | config.ntp_server, sizeof(config.ntp_server));
        config.timezone = doc["timezone"] | config.timezone;
        
        JsonArray scheduleArr = doc["schedule"].as<JsonArray>();
        for (int i = 0; i < 3 && i < scheduleArr.size(); i++) {
          strlcpy(config.schedule[i], scheduleArr[i] | config.schedule[i], 32);
        }
        
        config.button_enabled = doc["button_enabled"] | config.button_enabled;
        config.button_gpio = doc["button_gpio"] | config.button_gpio;
        config.button_wake_time = doc["button_wake_time"] | config.button_wake_time;
        
        JsonArray thArr = doc["thresholds"].as<JsonArray>();
        for (int i = 0; i < 4 && i < thArr.size(); i++) {
          config.thresholds[i] = thArr[i] | config.thresholds[i];
        }
        
        JsonArray namesArr = doc["level_names"].as<JsonArray>();
        for (int i = 0; i < 4 && i < namesArr.size(); i++) {
          strlcpy(config.level_names[i], namesArr[i] | config.level_names[i], 32);
        }
        
        config.temp_enabled = doc["temp_enabled"] | config.temp_enabled;
        config.temp_gpio = doc["temp_gpio"] | config.temp_gpio;
        config.font_scale_co2 = doc["font_scale_co2"] | config.font_scale_co2;
        config.font_scale_temp = doc["font_scale_temp"] | config.font_scale_temp;
        config.font_scale_info = doc["font_scale_info"] | config.font_scale_info;
        config.disable_animation = doc["disable_animation"] | config.disable_animation;
        config.disable_movement = doc["disable_movement"] | config.disable_movement;

        if (config.font_scale_co2 < 1) config.font_scale_co2 = 1;
        if (config.font_scale_co2 > 3) config.font_scale_co2 = 3;
        if (config.font_scale_temp < 1) config.font_scale_temp = 1;
        if (config.font_scale_temp > 3) config.font_scale_temp = 3;
        if (config.font_scale_info < 1) config.font_scale_info = 1;
        if (config.font_scale_info > 3) config.font_scale_info = 3;
      } else {
        Serial.println("Failed to parse config.json");
      }
      file.close();
    }
  } else {
    Serial.println("No config.json, using defaults");
    saveConfig();
  }
  SPIFFS.end();
}

void saveConfig() {
  if (!SPIFFS.begin(true)) return;
  JsonDocument doc;
  
  doc["ssid"] = config.ssid;
  doc["password"] = config.password;
  doc["mqtt_server"] = config.mqtt_server;
  doc["mqtt_port"] = config.mqtt_port;
  doc["mqtt_user"] = config.mqtt_user;
  doc["mqtt_pass"] = config.mqtt_pass;
  doc["mqtt_topic_co2"] = config.mqtt_topic_co2;
  doc["mqtt_topic_temp"] = config.mqtt_topic_temp;
  doc["ntp_server"] = config.ntp_server;
  doc["timezone"] = config.timezone;
  
  JsonArray scheduleArr = doc["schedule"].to<JsonArray>();
  for (int i = 0; i < 3; i++) {
    scheduleArr.add(config.schedule[i]);
  }
  
  doc["button_enabled"] = config.button_enabled;
  doc["button_gpio"] = config.button_gpio;
  doc["button_wake_time"] = config.button_wake_time;
  
  JsonArray thArr = doc["thresholds"].to<JsonArray>();
  for (int i = 0; i < 4; i++) {
    thArr.add(config.thresholds[i]);
  }
  
  JsonArray namesArr = doc["level_names"].to<JsonArray>();
  for (int i = 0; i < 4; i++) {
    namesArr.add(config.level_names[i]);
  }
  
  doc["temp_enabled"] = config.temp_enabled;
  doc["temp_gpio"] = config.temp_gpio;
  doc["font_scale_co2"] = config.font_scale_co2;
  doc["font_scale_temp"] = config.font_scale_temp;
  doc["font_scale_info"] = config.font_scale_info;
  doc["disable_animation"] = config.disable_animation;
  doc["disable_movement"] = config.disable_movement;

  File file = SPIFFS.open("/config.json", "w");
  if (file) {
    serializeJson(doc, file);
    file.close();
    Serial.println("Config saved");
  }
  SPIFFS.end();
}