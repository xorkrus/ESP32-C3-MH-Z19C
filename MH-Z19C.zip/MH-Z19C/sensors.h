#ifndef SENSORS_H
#define SENSORS_H

#include <Arduino.h>

int readCO2FromPWM(int pin);
void readTemperature();

#endif