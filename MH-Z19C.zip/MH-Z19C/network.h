#ifndef NETWORK_H
#define NETWORK_H

#include <Arduino.h>

void setupAP();
void setupWiFi();
void reconnectMQTT();
void sendMqtt();

#endif