#ifndef DISPLAY_H
#define DISPLAY_H

#include <Arduino.h>
#include "globals.h"

bool isScheduleOff();
bool shouldDisplayOn();
void setDisplayPower(bool on);

void initBubbles();
void updateBubbles();
void drawBubbles(int digitsX, int digitsY, int digitsW, int digitsH);

void updateDisplayContent();

#endif