#ifndef CONFIG_H
#define CONFIG_H

#include <Arduino.h>

// ========== ВЕРСИЯ И ДАТА СБОРКИ ==========
#define FW_VERSION "2.6"
#define BUILD_TIMESTAMP __DATE__ " " __TIME__

// ========== ПИНЫ ==========
#define I2C_SDA   2
#define I2C_SCL   3
#define PWM_PIN   4
#define BUTTON_PIN 5

// ========== ДИСПЛЕЙ ==========
#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1

struct Config {
  char ssid[32] = "xopkland";
  char password[64] = "1234567890987654321";
  char mqtt_server[40] = "192.168.1.42";
  int mqtt_port = 1883;
  char mqtt_user[32] = "";
  char mqtt_pass[32] = "";
  char mqtt_topic_co2[64] = "CO2/ppm";
  char mqtt_topic_temp[64] = "temperature";
  char ntp_server[40] = "pool.ntp.org";
  int timezone = 3;

  char schedule[3][32] = {"0:00-6:00,127", "8:00-16:00,31", ""};

  bool button_enabled = true;
  int button_gpio = BUTTON_PIN;
  int button_wake_time = 30;

  int thresholds[4] = {800, 1200, 1800, 5000};
  char level_names[4][32] = {"Норма", "Внимание", "Опасно", "Полный абзац"};

  bool temp_enabled = true;
  int temp_gpio = 6;

  int font_scale_co2 = 3;
  int font_scale_temp = 1;
  int font_scale_info = 1;

  bool disable_animation = false;
  bool disable_movement = false;
};

extern Config config;

void loadConfig();
void saveConfig();

#endif