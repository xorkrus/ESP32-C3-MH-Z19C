#include "sensors.h"
#include "globals.h"
#include "config.h"

int readCO2FromPWM(int pin) {
  unsigned long th_us = pulseIn(pin, HIGH, 2000000);
  unsigned long tl_us = pulseIn(pin, LOW, 2000000);

  if (th_us == 0 || tl_us == 0) return -1;

  float th_ms = th_us / 1000.0;
  float tl_ms = tl_us / 1000.0;
  float period = th_ms + tl_ms;

  if (period < 950 || period > 1050) return -1;

  float ppm = 5000.0 * (th_ms - 2.0) / (period - 4.0);
  if (ppm < 400) ppm = 400;
  if (ppm > 5000) ppm = 5000;
  return (int)ppm;
}

void readTemperature() {
  if (!config.temp_enabled || sensors == nullptr) {
    currentTemp = -127.0;
    return;
  }
  sensors->requestTemperatures();
  float temp = sensors->getTempCByIndex(0);
  if (temp != DEVICE_DISCONNECTED_C) {
    currentTemp = temp;
  } else {
    currentTemp = -127.0;
  }
}