// globals.h
#ifndef GLOBALS_H
#define GLOBALS_H

#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Добавляем заголовки, необходимые для WiFi на ESP32
#include <esp_event.h>
#include <esp_wifi.h>
#include <WiFi.h>
#include <PubSubClient.h>
#include <NTPClient.h>
#include <WiFiUdp.h>
#include <WebServer.h>
#include <OneWire.h>
#include <DallasTemperature.h>

#include "config.h"

// I2C и дисплей
extern TwoWire I2Cbus;
extern Adafruit_SSD1306 display;

// NTP
extern WiFiUDP ntpUDP;
extern NTPClient timeClient;

// MQTT
extern WiFiClient espClient;
extern PubSubClient mqttClient;

// Web
extern WebServer server;

// Тайминги
extern unsigned long lastUpdate;
extern const unsigned long UPDATE_INTERVAL;
extern unsigned long lastMqttSend;
extern const unsigned long MQTT_INTERVAL;
extern unsigned long lastTempRead;
extern const unsigned long TEMP_READ_INTERVAL;

// Данные
extern int currentPpm;
extern float currentTemp;
extern bool displayState;
extern bool scheduleEnabled;
extern unsigned long buttonWakeUntil;

// Анимация
struct Bubble {
  int x, y;
  int radius;
  int speed;
  bool active;
  bool filled;
};
#define MAX_BUBBLES 15
extern Bubble bubbles[MAX_BUBBLES];
extern int numberOffsetX;
extern int numberOffsetY;

// Движение уровня
extern int levelNamePos;
extern unsigned long lastLevelPosChange;
extern const unsigned long LEVEL_POS_INTERVAL;

// История
#define HISTORY_SIZE 20
extern int co2History[HISTORY_SIZE];
extern float tempHistory[HISTORY_SIZE];
extern int historyIndex;
extern int historyCount;
extern unsigned long lastHistoryAdd;
extern const unsigned long HISTORY_ADD_INTERVAL;

// IP
extern String lastIP;
extern unsigned long ipDisplayUntil;

// Режим AP
extern bool apMode;
extern const String apSSIDprefix;

// Кнопка (состояния) – объявление enum
enum ButtonState { BUTTON_IDLE, BUTTON_PRESSED, BUTTON_HELD };
extern ButtonState btnState;
extern unsigned long buttonPressTime;
extern bool buttonLongPressHandled;
extern const unsigned long LONG_PRESS_MS;

// Датчик температуры
extern OneWire* oneWire;
extern DallasTemperature* sensors;

#endif
