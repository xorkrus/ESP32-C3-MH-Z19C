#include "web.h"
#include "globals.h"
#include "config.h"
#include <ArduinoJson.h>

void addToHistory(int co2, float temp) {
  co2History[historyIndex] = co2;
  tempHistory[historyIndex] = temp;
  historyIndex = (historyIndex + 1) % HISTORY_SIZE;
  if (historyCount < HISTORY_SIZE) historyCount++;
}

void handleRoot() {
  String modeInfo = apMode ? " (AP mode)" : "";
  String html = R"rawliteral(
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>CO₂ Monitor Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: Arial, sans-serif;
            background: #f0f2f5;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 10px;
        }
        .dashboard {
            max-width: 800px;
            width: 100%;
            background: white;
            border-radius: 12px;
            padding: 15px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        .values-row {
            display: flex;
            justify-content: center;
            align-items: baseline;
            gap: 20px;
            flex-wrap: wrap;
            margin-bottom: 20px;
        }
        .co2-value {
            font-size: 4rem;
            font-weight: bold;
            color: #2c3e50;
        }
        .temp-value {
            font-size: 2rem;
            color: #2c3e50;
        }
        canvas {
            max-width: 100%;
            height: auto;
            background: #fff;
            border-radius: 8px;
            margin-top: 10px;
        }
        .config-link {
            margin-top: 15px;
        }
        .config-link a {
            color: #2c3e50;
            text-decoration: none;
            font-weight: bold;
        }
        .footer {
            margin-top: 15px;
            font-size: 0.8rem;
            color: #777;
        }
        .mode-badge {
            background: #e67e22;
            color: white;
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.7rem;
            margin-left: 10px;
            vertical-align: middle;
        }
        @media (max-width: 600px) {
            .co2-value { font-size: 2.5rem; }
            .temp-value { font-size: 1.5rem; }
        }
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="dashboard">
    <h1>CO₂ Monitor)rawliteral" + modeInfo + R"rawliteral(</h1>
    <div class="values-row">
        <div class="co2-value" id="co2">-- ppm</div>
        <div class="temp-value" id="temp">-- °C</div>
    </div>
    <canvas id="co2Chart" width="600" height="300"></canvas>
    <div class="config-link"><a href="/config">Настройки</a></div>
    <div class="footer">Версия )rawliteral" + String(FW_VERSION) + R"rawliteral( | Сборка: )rawliteral" + String(BUILD_TIMESTAMP) + R"rawliteral(</div>
</div>
<script>
    const ctx = document.getElementById('co2Chart').getContext('2d');
    let chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                label: 'CO₂ (ppm)',
                data: [],
                borderColor: 'rgb(75, 192, 192)',
                tension: 0.1,
                fill: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: true,
            scales: {
                y: { title: { display: true, text: 'ppm' } }
            }
        }
    });

    function fetchData() {
        fetch('/api/data')
            .then(response => response.json())
            .then(data => {
                document.getElementById('co2').innerText = data.current_co2 + ' ppm';
                if (data.current_temp !== null) {
                    document.getElementById('temp').innerText = data.current_temp.toFixed(1) + ' °C';
                } else {
                    document.getElementById('temp').innerText = '-- °C';
                }
                chart.data.labels = data.labels;
                chart.data.datasets[0].data = data.co2_values;
                chart.update();
            })
            .catch(error => {
                console.error('Error fetching data:', error);
                setTimeout(fetchData, 5000);
            });
    }
    fetchData();
    setInterval(fetchData, 10000);
</script>
</body>
</html>
)rawliteral";
  server.send(200, "text/html", html);
}

void handleApiData() {
  JsonDocument doc;
  doc["current_co2"] = currentPpm;
  doc["current_temp"] = (config.temp_enabled && currentTemp > -100.0) ? currentTemp : (float)NULL;
  JsonArray labels = doc["labels"].to<JsonArray>();
  JsonArray co2Arr = doc["co2_values"].to<JsonArray>();
  for (int i = 0; i < historyCount; i++) {
    int idx = (historyIndex - historyCount + i + HISTORY_SIZE) % HISTORY_SIZE;
    labels.add(i + 1);
    co2Arr.add(co2History[idx]);
  }
  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
}

void handleConfig() {
  String modeInfo = apMode ? " (AP mode)" : "";
  String html = R"rawliteral(
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes">
    <title>CO₂ Monitor Config</title>
    <style>
        * { box-sizing: border-box; }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f0f2f5;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .container {
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: #2c3e50;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 1.8rem;
        }
        .version {
            font-size: 0.8rem;
            opacity: 0.8;
            margin-top: 5px;
        }
        .tabs-wrapper {
            overflow-x: auto;
            overflow-y: hidden;
            -webkit-overflow-scrolling: touch;
            scrollbar-width: thin;
            background: #ecf0f1;
            border-bottom: 1px solid #ddd;
        }
        .tabs {
            display: flex;
            flex-wrap: nowrap;
            min-width: min-content;
            white-space: nowrap;
        }
        .tab-btn {
            background: none;
            border: none;
            padding: 12px 20px;
            cursor: pointer;
            font-size: 0.9rem;
            transition: 0.2s;
            color: #2c3e50;
            white-space: nowrap;
        }
        .tab-btn:hover {
            background: #d5dbdb;
        }
        .tab-btn.active {
            background: white;
            border-bottom: 2px solid #2c3e50;
            font-weight: bold;
        }
        .tab-content {
            display: none;
            padding: 20px;
        }
        .tab-content.active {
            display: block;
        }
        .section {
            margin-bottom: 20px;
        }
        .section h2 {
            margin: 0 0 15px 0;
            font-size: 1.2rem;
            color: #2c3e50;
            border-left: 4px solid #2c3e50;
            padding-left: 10px;
        }
        .form-group {
            margin-bottom: 12px;
            display: flex;
            flex-wrap: wrap;
            align-items: center;
        }
        .form-group label {
            flex: 1;
            min-width: 140px;
            font-weight: 500;
            margin-bottom: 5px;
        }
        .form-group input, .form-group select {
            flex: 2;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
        }
        .form-group input[type="checkbox"] {
            flex: none;
            width: 20px;
            height: 20px;
            margin-left: 0;
        }
        .schedule-group {
            margin-bottom: 12px;
        }
        .schedule-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 6px;
        }
        .threshold-group {
            display: flex;
            flex-wrap: wrap;
            gap: 10px;
            margin-bottom: 10px;
        }
        .threshold-group input {
            flex: 1;
        }
        .btn {
            background: #2c3e50;
            color: white;
            border: none;
            padding: 12px 24px;
            font-size: 1rem;
            border-radius: 6px;
            cursor: pointer;
            transition: background 0.2s;
            margin-top: 10px;
        }
        .btn:hover {
            background: #1e2b36;
        }
        .pin-group {
            margin-top: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        .error {
            color: #e74c3c;
            font-size: 0.9rem;
            margin-top: 10px;
        }
        .footer {
            text-align: center;
            padding: 15px;
            font-size: 0.8rem;
            color: #777;
            border-top: 1px solid #eee;
        }
        .footer a {
            color: #2c3e50;
            text-decoration: none;
        }
        @media (max-width: 600px) {
            body { padding: 10px; }
            .form-group {
                flex-direction: column;
                align-items: stretch;
            }
            .form-group label {
                margin-bottom: 5px;
            }
            .tab-btn {
                padding: 10px 15px;
                font-size: 0.85rem;
            }
        }
        @media (max-width: 480px) {
            .tab-btn {
                padding: 8px 12px;
                font-size: 0.8rem;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>CO₂ Monitor)rawliteral" + modeInfo + R"rawliteral(</h1>
        <div class="version">Версия )rawliteral" + String(FW_VERSION) + R"rawliteral( | Сборка: )rawliteral" + String(BUILD_TIMESTAMP) + R"rawliteral(</div>
    </div>

    <div class="tabs-wrapper">
        <div class="tabs">
            <button class="tab-btn active" data-tab="wifi">Wi-Fi</button>
            <button class="tab-btn" data-tab="mqtt">MQTT</button>
            <button class="tab-btn" data-tab="ntp">NTP</button>
            <button class="tab-btn" data-tab="schedule">Расписание</button>
            <button class="tab-btn" data-tab="button">Кнопка</button>
            <button class="tab-btn" data-tab="co2">CO₂ пороги</button>
            <button class="tab-btn" data-tab="temp">Температура</button>
            <button class="tab-btn" data-tab="display">Дисплей</button>
        </div>
    </div>

    <form method="POST" action="/save">
)rawliteral";

  html += R"rawliteral(
        <div class="tab-content active" id="wifi">
            <div class="section">
                <h2>Настройки Wi-Fi</h2>
                <div class="form-group"><label>SSID:</label><input name='ssid' value=')rawliteral" + String(config.ssid) + R"rawliteral('></div>
                <div class="form-group"><label>Пароль:</label><input name='password' type='password' value=')rawliteral" + String(config.password) + R"rawliteral('></div>
            </div>
        </div>
)rawliteral";

  html += R"rawliteral(
        <div class="tab-content" id="mqtt">
            <div class="section">
                <h2>Настройки MQTT</h2>
                <div class="form-group"><label>Сервер:</label><input name='mqtt_server' value=')rawliteral" + String(config.mqtt_server) + R"rawliteral('></div>
                <div class="form-group"><label>Порт:</label><input name='mqtt_port' value=')rawliteral" + String(config.mqtt_port) + R"rawliteral('></div>
                <div class="form-group"><label>Логин:</label><input name='mqtt_user' value=')rawliteral" + String(config.mqtt_user) + R"rawliteral('></div>
                <div class="form-group"><label>Пароль:</label><input name='mqtt_pass' type='password' value=')rawliteral" + String(config.mqtt_pass) + R"rawliteral('></div>
                <div class="form-group"><label>Топик CO₂:</label><input name='mqtt_topic_co2' value=')rawliteral" + String(config.mqtt_topic_co2) + R"rawliteral('></div>
                <div class="form-group"><label>Топик температуры:</label><input name='mqtt_topic_temp' value=')rawliteral" + String(config.mqtt_topic_temp) + R"rawliteral('></div>
            </div>
        </div>
)rawliteral";

  html += R"rawliteral(
        <div class="tab-content" id="ntp">
            <div class="section">
                <h2>Настройки NTP</h2>
                <div class="form-group"><label>Сервер:</label><input name='ntp_server' value=')rawliteral" + String(config.ntp_server) + R"rawliteral('></div>
                <div class="form-group"><label>Часовой пояс (часы):</label><input name='timezone' value=')rawliteral" + String(config.timezone) + R"rawliteral('></div>
            </div>
        </div>
)rawliteral";

  html += R"rawliteral(
        <div class="tab-content" id="schedule">
            <div class="section">
                <h2>Расписание выключения экрана</h2>
                <div class="form-group"><small>Формат: HH:MM-HH:MM,маска_дней (маска: биты 0-6, бит0=пн...бит6=вс). Пример: 0:00-6:00,127</small></div>
                <div class="schedule-group"><input name='schedule0' value=')rawliteral" + String(config.schedule[0]) + R"rawliteral(' placeholder='Интервал 1'></div>
                <div class="schedule-group"><input name='schedule1' value=')rawliteral" + String(config.schedule[1]) + R"rawliteral(' placeholder='Интервал 2'></div>
                <div class="schedule-group"><input name='schedule2' value=')rawliteral" + String(config.schedule[2]) + R"rawliteral(' placeholder='Интервал 3'></div>
            </div>
        </div>
)rawliteral";

  String btnChecked = config.button_enabled ? "checked" : "";
  html += R"rawliteral(
        <div class="tab-content" id="button">
            <div class="section">
                <h2>Кнопка пробуждения</h2>
                <div class="form-group"><label>Включена:</label><input type='checkbox' name='button_enabled' )rawliteral" + btnChecked + R"rawliteral('></div>
                <div class="form-group"><label>GPIO:</label><input name='button_gpio' value=')rawliteral" + String(config.button_gpio) + R"rawliteral('></div>
                <div class="form-group"><label>Время пробуждения (сек):</label><input name='button_wake_time' value=')rawliteral" + String(config.button_wake_time) + R"rawliteral('></div>
                <div class="form-group"><small>* Краткое нажатие = пробуждение на указанное время. Долгое удержание = пробуждение на время удержания.</small></div>
            </div>
        </div>
)rawliteral";

  html += R"rawliteral(
        <div class="tab-content" id="co2">
            <div class="section">
                <h2>Пороги CO₂</h2>
)rawliteral";
  for (int i = 0; i < 4; i++) {
    html += "<div class='threshold-group'>";
    html += "<input name='threshold" + String(i) + "' value='" + String(config.thresholds[i]) + "' placeholder='Порог " + String(i+1) + "' size='5'>";
    html += "<input name='levelname" + String(i) + "' value='" + String(config.level_names[i]) + "' placeholder='Название уровня' style='flex:2'>";
    html += "</div>";
  }
  html += R"rawliteral(
            </div>
        </div>
)rawliteral";

  String tempChecked = config.temp_enabled ? "checked" : "";
  html += R"rawliteral(
        <div class="tab-content" id="temp">
            <div class="section">
                <h2>Датчик температуры DS18B20</h2>
                <div class="form-group"><label>Включен:</label><input type='checkbox' name='temp_enabled' )rawliteral" + tempChecked + R"rawliteral('></div>
                <div class="form-group"><label>GPIO:</label><input name='temp_gpio' value=')rawliteral" + String(config.temp_gpio) + R"rawliteral('></div>
            </div>
        </div>
)rawliteral";

  html += R"rawliteral(
        <div class="tab-content" id="display">
            <div class="section">
                <h2>Настройки дисплея</h2>
                <div class="form-group"><label>Размер шрифта PPM (1-3):</label><select name='font_scale_co2'>
)rawliteral";
  for (int i = 1; i <= 3; i++) {
    html += "<option value='" + String(i) + "'" + (config.font_scale_co2 == i ? " selected" : "") + ">" + String(i) + "</option>";
  }
  html += R"rawliteral(
                </select></div>
                <div class="form-group"><label>Размер шрифта температуры (1-3):</label><select name='font_scale_temp'>
)rawliteral";
  for (int i = 1; i <= 3; i++) {
    html += "<option value='" + String(i) + "'" + (config.font_scale_temp == i ? " selected" : "") + ">" + String(i) + "</option>";
  }
  html += R"rawliteral(
                </select></div>
                <div class="form-group"><label>Размер шрифта инфо (1-3):</label><select name='font_scale_info'>
)rawliteral";
  for (int i = 1; i <= 3; i++) {
    html += "<option value='" + String(i) + "'" + (config.font_scale_info == i ? " selected" : "") + ">" + String(i) + "</option>";
  }
  String animChecked = config.disable_animation ? "checked" : "";
  String moveChecked = config.disable_movement ? "checked" : "";
  html += R"rawliteral(
                </select></div>
                <div class="form-group"><label>Отключить анимацию (пузырьки):</label><input type='checkbox' name='disable_animation' )rawliteral" + animChecked + R"rawliteral('></div>
                <div class="form-group"><label>Отключить перемещение (дрейф, рамка):</label><input type='checkbox' name='disable_movement' )rawliteral" + moveChecked + R"rawliteral('></div>
                <div class="form-group"><small>При отключении перемещения цифры фиксируются по центру, рамка не рисуется, уровень CO₂ всегда слева внизу.</small></div>
            </div>
        </div>
)rawliteral";

  html += R"rawliteral(
        <div class="pin-group">
            <div class="form-group">
                <label>ПИН-код для сохранения:</label>
                <input type="password" name="pin" placeholder="0000" required>
            </div>
        </div>
        <button type="submit" class="btn">Сохранить и перезагрузить</button>
        <div class="error" id="pinError" style="display:none;">Неверный PIN-код</div>
    </form>

    <div class="footer">
        <a href="/">Вернуться к дашборду</a> | <a href="https://github.com/xorkrus/ESP32-C3-MH-Z19C" target="_blank">Исходный код на GitHub</a>
    </div>
</div>

<script>
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const tabId = btn.getAttribute('data-tab');
            document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
        });
    });

    document.querySelector('form').addEventListener('submit', function(e) {
        var pin = document.querySelector('input[name="pin"]').value;
        if (pin !== "0000") {
            e.preventDefault();
            document.getElementById('pinError').style.display = 'block';
        }
    });
</script>
</body>
</html>
)rawliteral";

  server.send(200, "text/html", html);
}

void handleSave() {
  if (!server.hasArg("pin") || server.arg("pin") != "0000") {
    server.send(403, "text/plain", "Неверный PIN-код");
    return;
  }

  if (server.hasArg("ssid")) strlcpy(config.ssid, server.arg("ssid").c_str(), sizeof(config.ssid));
  if (server.hasArg("password")) strlcpy(config.password, server.arg("password").c_str(), sizeof(config.password));
  if (server.hasArg("mqtt_server")) strlcpy(config.mqtt_server, server.arg("mqtt_server").c_str(), sizeof(config.mqtt_server));
  if (server.hasArg("mqtt_port")) config.mqtt_port = server.arg("mqtt_port").toInt();
  if (server.hasArg("mqtt_user")) strlcpy(config.mqtt_user, server.arg("mqtt_user").c_str(), sizeof(config.mqtt_user));
  if (server.hasArg("mqtt_pass")) strlcpy(config.mqtt_pass, server.arg("mqtt_pass").c_str(), sizeof(config.mqtt_pass));
  if (server.hasArg("mqtt_topic_co2")) strlcpy(config.mqtt_topic_co2, server.arg("mqtt_topic_co2").c_str(), sizeof(config.mqtt_topic_co2));
  if (server.hasArg("mqtt_topic_temp")) strlcpy(config.mqtt_topic_temp, server.arg("mqtt_topic_temp").c_str(), sizeof(config.mqtt_topic_temp));
  if (server.hasArg("ntp_server")) strlcpy(config.ntp_server, server.arg("ntp_server").c_str(), sizeof(config.ntp_server));
  if (server.hasArg("timezone")) config.timezone = server.arg("timezone").toInt();
  for (int i = 0; i < 3; i++) {
    String param = "schedule" + String(i);
    if (server.hasArg(param)) strlcpy(config.schedule[i], server.arg(param).c_str(), 32);
  }
  config.button_enabled = server.hasArg("button_enabled");
  if (server.hasArg("button_gpio")) config.button_gpio = server.arg("button_gpio").toInt();
  if (server.hasArg("button_wake_time")) config.button_wake_time = server.arg("button_wake_time").toInt();
  for (int i = 0; i < 4; i++) {
    String thParam = "threshold" + String(i);
    if (server.hasArg(thParam)) config.thresholds[i] = server.arg(thParam).toInt();
    String nameParam = "levelname" + String(i);
    if (server.hasArg(nameParam)) strlcpy(config.level_names[i], server.arg(nameParam).c_str(), 32);
  }
  config.temp_enabled = server.hasArg("temp_enabled");
  if (server.hasArg("temp_gpio")) config.temp_gpio = server.arg("temp_gpio").toInt();

  if (server.hasArg("font_scale_co2")) config.font_scale_co2 = server.arg("font_scale_co2").toInt();
  if (server.hasArg("font_scale_temp")) config.font_scale_temp = server.arg("font_scale_temp").toInt();
  if (server.hasArg("font_scale_info")) config.font_scale_info = server.arg("font_scale_info").toInt();
  config.disable_animation = server.hasArg("disable_animation");
  config.disable_movement = server.hasArg("disable_movement");

  if (config.font_scale_co2 < 1) config.font_scale_co2 = 1;
  if (config.font_scale_co2 > 3) config.font_scale_co2 = 3;
  if (config.font_scale_temp < 1) config.font_scale_temp = 1;
  if (config.font_scale_temp > 3) config.font_scale_temp = 3;
  if (config.font_scale_info < 1) config.font_scale_info = 1;
  if (config.font_scale_info > 3) config.font_scale_info = 3;

  saveConfig();
  server.send(200, "text/html", "<html><body><h2>Настройки сохранены, перезагрузка...</h2></body></html>");
  delay(1000);
  ESP.restart();
}

void setupWebServer() {
  server.on("/", HTTP_GET, handleRoot);
  server.on("/config", HTTP_GET, handleConfig);
  server.on("/api/data", HTTP_GET, handleApiData);
  server.on("/save", HTTP_POST, handleSave);
  server.begin();
  Serial.println("HTTP server started");
}